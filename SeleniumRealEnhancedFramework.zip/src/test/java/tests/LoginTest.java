package tests;

import org.testng.annotations.Test;
import pages.LoginPage;
import base.BaseTest;

public class LoginTest extends BaseTest {

    @Test(retryAnalyzer = utils.RetryAnalyzer.class)
    public void loginShouldSucceed() {
        LoginPage login = new LoginPage(driver);
        login.login("admin", "admin123");
    }
}
