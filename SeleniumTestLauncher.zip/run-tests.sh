#!/bin/bash
echo "Running Selenium Test Suite..."
mvn clean test
echo "Opening latest Extent Report..."
xdg-open $(ls -t test-output/ExtentReport_*.html | head -n 1)
