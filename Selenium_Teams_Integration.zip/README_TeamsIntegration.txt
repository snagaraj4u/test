# Microsoft Teams Integration Instructions

## 📌 Steps to Use the Teams Notifier in Your Selenium TestNG Framework

1. **Upload `TeamsNotifier.java` to your framework's `utils` package**.

2. **Generate Teams Webhook:**
   - Go to your Microsoft Teams channel
   - Click on `...` → `Connectors` → Add `Incoming Webhook`
   - Name it and copy the **Webhook URL**

3. **Update the Webhook URL** inside `TeamsNotifier.java`:
   Replace:
   ```java
   String webhookUrl = "https://outlook.office.com/webhook/your-webhook-url";
   ```
   With your actual URL.

4. **Send Notification After Test Execution:**

   In `BaseTest.java` or any suite-level class, add:

   ```java
   import utils.TeamsNotifier;

   @AfterSuite
   public void tearDownSuite() {
       String reportLink = "file:///" + System.getProperty("user.dir") + "/test-output/ExtentReport_<timestamp>.html";
       TeamsNotifier.sendTestReportToTeams("✅ Automation execution completed. Please review the Extent Report.");
   }
   ```

5. **Optional: Test Notification**
   You can test it with:

   ```java
   public static void main(String[] args) {
       TeamsNotifier.sendTestReportToTeams("🔔 Test notification from Selenium Framework!");
   }
   ```

---

✅ That’s it! Now your test results will be pushed directly to Teams after execution.
