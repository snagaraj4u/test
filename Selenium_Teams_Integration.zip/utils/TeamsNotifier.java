package utils;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class TeamsNotifier {
    public static void sendTestReportToTeams(String message) {
        try {
            String webhookUrl = "https://outlook.office.com/webhook/your-webhook-url"; // Replace with your actual Teams webhook
            URL url = new URL(webhookUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String jsonPayload = "{ \"text\": \"" + message + "\" }";

            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            writer.write(jsonPayload);
            writer.flush();
            writer.close();

            int responseCode = conn.getResponseCode();
            System.out.println("Teams response code: " + responseCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
